def hello():
    print("Hello pyproject.toml!")
